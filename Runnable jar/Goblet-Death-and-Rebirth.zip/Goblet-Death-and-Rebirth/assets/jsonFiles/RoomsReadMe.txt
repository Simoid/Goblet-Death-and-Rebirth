Vad  i arrayen i rooms.json betyder:

"0" = inget
"x" = sten
